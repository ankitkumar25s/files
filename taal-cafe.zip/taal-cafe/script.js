// Mobile menu toggle
const btn = document.querySelector('.menu-btn');
const nav = document.getElementById('nav');
btn.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  btn.setAttribute('aria-expanded', open);
});
nav.addEventListener('click', e => { if (e.target.tagName === 'A') { nav.classList.remove('open'); btn.setAttribute('aria-expanded', false); } });

// Simple form validation
const form = document.getElementById('bookForm');
const msg = document.getElementById('msg');
document.getElementById('date').min = new Date().toISOString().split('T')[0];
form.addEventListener('submit', e => {
  e.preventDefault();
  if (!form.checkValidity()) { msg.textContent = 'Kripya sabhi fields sahi se bharein.'; msg.className = 'err'; return; }
  msg.textContent = `Shukriya ${form.name.value}! Aapki booking request mil gayi.`; msg.className = 'ok'; form.reset();
});
