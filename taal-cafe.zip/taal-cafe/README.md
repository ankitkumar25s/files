# Taal Café: Responsive Website (Documentation)

## 1. Project Overview
Bhopal ke ek kalpanik café ki single-page website. Goal: ek hi codebase jo mobile, tablet aur desktop par sahi dikhe.

**Files**
| File | Kaam |
|---|---|
| `index.html` | Semantic structure |
| `style.css` | Mobile-first CSS + media queries |
| `script.js` | Mobile menu toggle + form validation |
| `images/*.svg` | Scalable (resolution-independent) images |

## 2. Planning
Pehle mobile (320px) ka single-column layout socha, phir badi screens par columns add kiye (**mobile-first**). Sections: Header, Hero, Menu, About, Gallery, Contact, Footer.

## 3. Semantic HTML
`header`, `nav`, `main`, `section`, `article`, `figure/figcaption`, `address`, `footer`; ek hi `h1`, headings ka sahi order, `alt` text, `lang` attribute, skip-link, ARIA (`aria-expanded`, `aria-controls`) hamburger button par.
`<meta name="viewport" content="width=device-width, initial-scale=1">` har device par sahi scaling ke liye zaroori hai.

## 4. Responsive Techniques Used
| Technique | Kahan use hua |
|---|---|
| **Media queries (min-width)** | 600px, 768px, 1024px, 1400px breakpoints |
| **CSS Grid + `auto-fit/minmax()`** | Menu cards khud columns adjust karte hain |
| **Flexbox** | Header, buttons, stats |
| **`clamp()` fluid typography** | h1, h2, body size, spacing |
| **Fluid images** | `max-width:100%; height:auto`, `aspect-ratio`, `object-fit:cover`, width/height attributes (layout shift se bachne ke liye), `loading="lazy"` |
| **CSS variables** | Colors, spacing, ek jagah se control |
| **`prefers-color-scheme`** | Automatic dark mode |
| **`prefers-reduced-motion`** | Animations band for sensitive users |
| **`hover:hover`** | Hover effects sirf mouse devices par |
| **`orientation` / `print`** | Landscape phone aur print layout |

## 5. Layout Adjustments

| Section | Mobile (<600) | Tablet (600–1023) | Desktop (1024+) |
|---|---|---|---|
| Navigation | Hamburger dropdown | Horizontal links (768+) | Horizontal links |
| Hero | Text upar, image neeche | 2 columns (768+) | 2 columns, bada heading |
| Menu cards | 1 column | 2–3 columns | 4 columns |
| About | Stacked | 2 columns (768+) | 2 columns |
| Gallery | 2 columns | 3 columns | 4 columns |
| Contact | Stacked | Side by side | Side by side |

## 6. Testing
Chrome DevTools (Ctrl+Shift+M) me test kiya: iPhone SE (375), Galaxy S20 (360), iPad (768), iPad Pro (1024), Laptop (1366), Full HD (1920). Ek **Responsive** mode me width ko 320px se 1920px tak slowly drag karke dekha ki kahin horizontal scroll ya toota hua layout na aaye. HTML ko W3C validator aur Lighthouse (Accessibility/Best Practices) se check karna chahiye.

## 7. Challenges & Solutions
1. **Horizontal scrolling mobile par:** `box-sizing:border-box`, `max-width:100%` aur `min(100% - 2rem, 1140px)` container se solve.
2. **Navigation chhoti screen par:** Hamburger menu + `aria-expanded`; 768px par CSS se desktop nav.
3. **Cards ke liye bahut saare breakpoints:** `repeat(auto-fit, minmax(...))` se breakpoint ki zaroorat kam hui.
4. **Images ka alag ratio:** `aspect-ratio` + `object-fit:cover` se sab images same shape me.
5. **Text size har screen par:** `clamp()` se bina extra media queries ke smooth scaling.
6. **Sticky header ke peeche anchor chhup jaana:** `scroll-padding-top`.

## 8. How to Run
`index.html` ko browser me double-click karke kholein. Kisi server ki zaroorat nahi.

## 9. Future Improvements
`srcset` ke saath real photos (WebP), multi-language toggle, backend se booking form connect karna.
